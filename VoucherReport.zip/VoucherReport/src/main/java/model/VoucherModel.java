package model;


/**
 * Created by etushch on 9/7/2017.
 */
public class VoucherModel {
    private String serial_number;
    private String state;
    private String changed_at;
    private String available_at;
    private String expiry_date;
    private String value;
    private String currency;
    private String agent;
    private String batch_id;
    private String voucher_group;
    private String subscriber_id;
    private String operator_id;
    private String extension_text_1;
    private String extension_text_2;
    private String extension_text_3;
    private String supplier_id;

    private boolean isCompliant;
    private String reasonDescription;

    public String getReasonDescription() {
        return reasonDescription;
    }

    public void setReasonDescription(String reasonDescription) {
        this.reasonDescription = reasonDescription;
    }

    public boolean isCompliant() {
        return isCompliant;
    }

    public void setCompliant(boolean compliant) {
        isCompliant = compliant;
    }


    public VoucherModel() {
    }

    public VoucherModel(String serial_number, String state, String changed_at, String available_at, String expiry_date, String value, String currency, String agent, String batch_id, String voucher_group, String subscriber_id, String operator_id, String extension_text_1, String extension_text_2, String extension_text_3, String supplier_id) {
        this.serial_number = serial_number;
        this.state = state;
        this.changed_at = changed_at;
        this.available_at = available_at;
        this.expiry_date = expiry_date;
        this.value = value;
        this.currency = currency;
        this.agent = agent;
        this.batch_id = batch_id;
        this.voucher_group = voucher_group;
        this.subscriber_id = subscriber_id;
        this.operator_id = operator_id;
        this.extension_text_1 = extension_text_1;
        this.extension_text_2 = extension_text_2;
        this.extension_text_3 = extension_text_3;
        this.supplier_id = supplier_id;
        reasonDescription = null;
        isCompliant = false;
    }

    public String getSerial_number() {
        return serial_number;
    }

    public void setSerial_number(String serial_number) {
        this.serial_number = serial_number;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getChanged_at() {
        return changed_at;
    }

    public void setChanged_at(String changed_at) {
        this.changed_at = changed_at;
    }

    public String getAvailable_at() {
        return available_at;
    }

    public void setAvailable_at(String available_at) {
        this.available_at = available_at;
    }

    public String getExpiry_date() {
        return expiry_date;
    }

    public void setExpiry_date(String expiry_date) {
        this.expiry_date = expiry_date;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getBatch_id() {
        return batch_id;
    }

    public void setBatch_id(String batch_id) {
        this.batch_id = batch_id;
    }

    public String getVoucher_group() {
        return voucher_group;
    }

    public void setVoucher_group(String voucher_group) {
        this.voucher_group = voucher_group;
    }

    public String getSubscriber_id() {
        return subscriber_id;
    }

    public void setSubscriber_id(String subscriber_id) {
        this.subscriber_id = subscriber_id;
    }

    public String getOperator_id() {
        return operator_id;
    }

    public void setOperator_id(String operator_id) {
        this.operator_id = operator_id;
    }

    public String getExtension_text_1() {
        return extension_text_1;
    }

    public void setExtension_text_1(String extension_text_1) {
        this.extension_text_1 = extension_text_1;
    }

    public String getExtension_text_2() {
        return extension_text_2;
    }

    public void setExtension_text_2(String extension_text_2) {
        this.extension_text_2 = extension_text_2;
    }

    public String getExtension_text_3() {
        return extension_text_3;
    }

    public void setExtension_text_3(String extension_text_3) {
        this.extension_text_3 = extension_text_3;
    }

    public String getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    @Override
    public String toString() {
        StringBuilder returnModelStr = new StringBuilder("");
        returnModelStr.append(serial_number).append(",").append(state).append(",").append(changed_at).append(",").
                append(available_at).append(",").append(expiry_date).append(",").append(value).append(",").append(currency).
                append(",").append(agent).append(",").append(batch_id).append(",").append(voucher_group).append(",").
                append(subscriber_id).append(",").append(operator_id).append(",").append(extension_text_1).append(",").
                append(extension_text_2).append(",").append(extension_text_3).append(",").append(supplier_id).append(" ").
                append(reasonDescription);
        return returnModelStr.toString();
    }
}

