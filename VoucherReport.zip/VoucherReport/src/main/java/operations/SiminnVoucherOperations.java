package operations;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import au.com.bytecode.opencsv.bean.CsvToBean;
import model.VoucherModel;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by etushch on 9/7/2017.
 */
public class SiminnVoucherOperations {
    private static Log logger = LogFactory.getLog(SiminnVoucherOperations.class);
    private List<VoucherModel> voucherMasterList;
    private List<VoucherModel> voucherValidList;
    private List<VoucherModel> voucherFilterList;
    private List<VoucherModel> voucherRegularFaceValueList;
    private List<VoucherModel> voucherComboFaceValueList;
    private List<VoucherModel> voucherDataFaceValueList;
    private List<VoucherModel> rejectedList;

    public SiminnVoucherOperations() {
        this.voucherMasterList = new java.util.ArrayList<VoucherModel>();
        this.voucherValidList = new java.util.ArrayList<VoucherModel>();
        this.voucherFilterList = new java.util.ArrayList<VoucherModel>();
        this.voucherRegularFaceValueList = new java.util.ArrayList<VoucherModel>();
        this.voucherComboFaceValueList = new java.util.ArrayList<VoucherModel>();
        this.voucherDataFaceValueList = new java.util.ArrayList<VoucherModel>();
        this.rejectedList = new java.util.ArrayList<VoucherModel>();
    }

    public List<VoucherModel> getVoucherRegularFaceValueList() {
        return voucherRegularFaceValueList;
    }

    public List<VoucherModel> getVoucherComboFaceValueList() {
        return voucherComboFaceValueList;
    }

    public List<VoucherModel> getVoucherDataFaceValueList() {
        return voucherDataFaceValueList;
    }

    public SiminnVoucherOperations(List<VoucherModel> voucherMasterList) {
        this.voucherMasterList = voucherMasterList;
    }

    public List<VoucherModel> getVoucherMasterList() {
        return voucherMasterList;
    }

    public void setVoucherMasterList(List<VoucherModel> voucherMasterList) {
        this.voucherMasterList = voucherMasterList;
    }

    public void addVoucherElementToMasterList(VoucherModel voucherModel){
        this.voucherMasterList.add(voucherModel);
    }

    public boolean readCSVAndPopulateModelElement(String sourceDirectoryPath) throws IOException {
        logger.debug("Reading CSV file and populating Model element .....");
        CsvToBean csv = new CsvToBean();
        CSVReader csvReader = null;
        //get all the files from a directory
        Collection<File> fileList = FileUtils.listFiles(new File(sourceDirectoryPath.toString()),null,false);
        if(fileList.size() == 0){
            logger.debug("There is no input file to process .... Aborting !!!");
            return false;
        }
        for (File file : fileList) {
            if (file.isFile()) {
                logger.debug("Processing Input File: "+file.getName());
                //System.out.println("Timestamp: "+new Date().toString()+" Processing File: "+file.getName());
                try {
                    csvReader = new CSVReader(new FileReader(file.getAbsoluteFile()));
                } catch (FileNotFoundException e) {
                    logger.error("File: "+file.getName()+" Not Found !!!! Aborting !!!");
                    e.printStackTrace();
                }

                ColumnPositionMappingStrategy<VoucherModel> beanStrategy = new ColumnPositionMappingStrategy<VoucherModel>();
                beanStrategy.setType(VoucherModel.class);
                beanStrategy.setColumnMapping(new String[]{"serial_number",
                                                           "state",
                                                           "changed_at",
                                                           "available_at",
                                                           "expiry_date",
                                                           "value",
                                                           "currency",
                                                           "agent",
                                                           "batch_id",
                                                           "voucher_group",
                                                           "subscriber_id",
                                                           "operator_id",
                                                           "extension_text_1",
                                                           "extension_text2",
                                                           "extension_text_3",
                                                           "supplier_id"});

                CsvToBean<VoucherModel> csvToBean = new CsvToBean<VoucherModel>();

                List<VoucherModel> listOfVoucherModel = csvToBean.parse(beanStrategy, csvReader);
                for (Object object : listOfVoucherModel) {
                    VoucherModel voucherModel = (VoucherModel) object;
                    this.addVoucherElementToMasterList(voucherModel);
                }
                logger.debug("Closing File Handle for File: "+file.getName());
                csvReader.close();
            }
        }
        return true;
    }

    public void filterVoucherValidList(){
        //System.out.println("Voucher Valid List Size: "+voucherValidList.size());
        for(VoucherModel vm:voucherValidList)
        {
            String expDate = vm.getExpiry_date();
            if(expDate.length() == 0)
                continue;
            DateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
            Date expDateD = null;
            try {
                expDateD = format.parse(expDate);
            }catch (ParseException pe){
                pe.printStackTrace();
            }
            Date today = new Date();

            if( (vm.getAvailable_at().length() == 0) ||
                (vm.getExpiry_date().length() == 0)  ||
                    (expDateD.before(new Date())) ||
                vm.getState().equalsIgnoreCase("USED") ||
                vm.getState().equalsIgnoreCase("STOLEN")||
                vm.getState().equalsIgnoreCase("DAMAGED")||
                vm.getState().equalsIgnoreCase("PENDING")||
                vm.getState().equalsIgnoreCase("RESERVED")||
                vm.getState().equalsIgnoreCase("UNAVAILABLE"))
            {
                //System.out.println("State: "+vm.getState());
                continue;
            }
            this.voucherFilterList.add(vm);
        }
        //System.out.println("Voucher Valid List Rendering Completed ....");
    }

    public void renderVoucherValidList(String rejectedFileName) throws IOException{
        File rejectedFile = new File(rejectedFileName);
        logger.debug("Rejected File: "+rejectedFile.getName());
        logger.debug("Voucher Master List Size: "+voucherMasterList.size());
        //System.out.println("Master List Size: "+voucherMasterList.size());
        for (VoucherModel vm:voucherMasterList
             ) {
            if(Utility.validateMandatoryFields(vm).isCompliant()){
                this.voucherValidList.add(vm);
            }
            else {
                logger.debug("Mandatory Field Missing in Corresponding Record - Skipping this entry !!!");
                this.rejectedList.add(vm);
                FileUtils.writeStringToFile(rejectedFile,vm.toString(),true);
                FileUtils.writeStringToFile(rejectedFile,"\n",true);
            }
        }
        logger.debug("Record Level validation completed ...");
        //System.out.println("Record Level validation completed ...");
    }

    public void renderFilterList(){
        for (VoucherModel vm:voucherFilterList){
            //System.out.println("Voucher Group: "+vm.getVoucher_group());
            if(vm.getVoucher_group().equalsIgnoreCase("v1")||vm.getVoucher_group().equalsIgnoreCase("v2")||vm.getVoucher_group().equalsIgnoreCase("vj")){
                this.voucherRegularFaceValueList.add(vm);
            }
            if(vm.getVoucher_group().equalsIgnoreCase("v3")){
                this.voucherComboFaceValueList.add(vm);
            }
            if(vm.getVoucher_group().equalsIgnoreCase("v4")){
                this.voucherDataFaceValueList.add(vm);
            }
        }
    }


    public void dumpVoucherModelRegularFace(){
        logger.debug("Regular Face List Size: "+voucherRegularFaceValueList.size());
        for (VoucherModel vm : voucherRegularFaceValueList){
            logger.debug(vm.toString());
        }
    }

    public void dumpVoucherModelComboFace(){
        logger.debug("Combo Face List Size: "+voucherComboFaceValueList.size());
        for (VoucherModel vm : voucherComboFaceValueList){
            logger.debug(vm.toString());
        }
    }

    public void dumpVoucherModelDataFace(){
        logger.debug("Data Face List Size: "+voucherDataFaceValueList.size());
        for (VoucherModel vm : voucherDataFaceValueList){
            logger.debug(vm.toString());
        }
    }
    public void dumpVoucherModel(){
        logger.debug("Filter List Size: "+this.voucherFilterList.size());
        dumpVoucherModelRegularFace();
        dumpVoucherModelComboFace();
        dumpVoucherModelDataFace();
    }

    public long totalRecordProcessed(){
        return voucherMasterList.size();
    }

    public long totalRegularRecordProcessed(){
        return voucherRegularFaceValueList.size();
    }

    public long totalComboRecordProcessed(){
        return voucherComboFaceValueList.size();
    }

    public long totalDataRecordProcessed(){
        return voucherDataFaceValueList.size();
    }

    public long totalRejectedRecords(){
        return rejectedList.size();
    }

    public long totalFilteredRecords(){
        return voucherMasterList.size() - (voucherRegularFaceValueList.size()+voucherComboFaceValueList.size()+voucherDataFaceValueList.size()+rejectedList.size());
    }
}