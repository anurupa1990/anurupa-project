package operations;

import model.VoucherModel;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.apache.commons.lang.time.DateUtils.MILLIS_PER_DAY;

public class Utility {

    private static Log logger = LogFactory.getLog(Utility.class);

/* */

    public static <K, V extends Comparable<V>> Map<K, V>
    sortMapInAscendingOrder(final Map<K, V> map) {
        Comparator<K> valueComparator =
                new Comparator<K>() {
                    public int compare(K k1, K k2) {
                        int compare =
                                map.get(k1).compareTo(map.get(k2));
                        if (compare == 0)
                            return 1;
                        else
                            return compare;
                    }
                };

        Map<K, V> sortedMap =
                new TreeMap<K, V>(valueComparator);
        sortedMap.putAll(map);
        return sortedMap;
    }


    public static StringBuilder populateStringBufferForVoucherElement (Map<Integer,Integer> sourceMap, StringBuilder sourceStringBuilder, String voucherCode){
       // Map<String,Integer> sortedMap = sortByValues(sourceMap);
        //SortedMap<Integer,Integer> sortedMap = new TreeMap<Integer, Integer>(sourceMap);
        for (Map.Entry<Integer, Integer> entry : sourceMap.entrySet()) {
            Integer intKey = entry.getKey();
            Integer value = entry.getValue();
            //Integer intKey = Integer.parseInt(key);
            Integer CalValue = intKey * value;
            String ss = String.format("                  %5d      %s              %5d             %5d", intKey, voucherCode, value, CalValue);
            sourceStringBuilder.append(ss);
            sourceStringBuilder.append("\n");
            //logger.debug("Mapping Rendering Completed for Key: "+key);
        }
        return sourceStringBuilder;
    }

    public static VoucherModel validateMandatoryFields(VoucherModel modelElement){
        StringBuilder reasonDesc = new StringBuilder("");
        if((modelElement.getState().length()>0) &&
           (modelElement.getAvailable_at().length()>0) &&
           (modelElement.getSerial_number().length()>0)&&
           (modelElement.getChanged_at().length()>0) &&
           (modelElement.getExpiry_date().length()>0) &&
           (modelElement.getValue().length()>0)&&
           (modelElement.getCurrency().length()>0) &&
           (modelElement.getBatch_id().length()>0) &&
           (modelElement.getVoucher_group().length()>0)){

            modelElement.setCompliant(true);
        }
        else {
            reasonDesc.append("[");
            if(modelElement.getState().length()==0){
                reasonDesc.append("STATE,");
            }
            if(modelElement.getAvailable_at().length()==0){
                reasonDesc.append("AVAILABLE_AT,");
            }
            if(modelElement.getSerial_number().length()==0){
                reasonDesc.append("SERIAL_NUMBER,");
            }
            if(modelElement.getChanged_at().length()==0){
                reasonDesc.append("CHANGED_AT,");
            }
            if(modelElement.getExpiry_date().length()==0){
                reasonDesc.append("EXPIRY_DATE,");
            }
            if(modelElement.getValue().length()==0){
                reasonDesc.append("VALUE,");
            }
            if(modelElement.getCurrency().length()==0){
                reasonDesc.append("CURRENCY,");
            }
            if(modelElement.getBatch_id().length()==0){
                reasonDesc.append("BATCH_ID,");
            }
            if(modelElement.getVoucher_group().length()==0){
                reasonDesc.append("VOUCHER_GROUP,");
            }
            reasonDesc.append(" IS MISSING IN THE RECORD]");
            modelElement.setCompliant(false);
            modelElement.setReasonDescription(replaceLast(reasonDesc.toString(),",",""));
        }
        return modelElement;
    }
/* Custom Method
   Replace Last occurance of a Character (as String)
 */

    private static String replaceLast(String string, String toReplace, String replacement) {
        int pos = string.lastIndexOf(toReplace);
        if (pos > -1) {
            return string.substring(0, pos)
                    + replacement
                    + string.substring(pos + toReplace.length(), string.length());
        } else {
            return string;
        }
    }

    public static void cleanEnvironment(String directoryName) throws IOException{
        FileUtils.cleanDirectory(new File(directoryName));
    }

    public static boolean copySourceFiles(String sourceDirPath, String tarDirName, String fileNameStartPattern, String extension) throws IOException, ParseException{
        StringBuilder outputFileStringBuilder = null;
        System.out.println("Source Dir Path: "+sourceDirPath);
        Collection<File> fileList = FileUtils.listFiles(new File(sourceDirPath.toString()),null,false);
        if(fileList.size() == 0){
            logger.debug("There is no input file to process .... Aborting !!!");
            return false;
        }

        for(File file:fileList){
            if(file.isFile()){
                outputFileStringBuilder = null;
                Path p = Paths.get(file.getAbsolutePath());
                BasicFileAttributes view = Files.getFileAttributeView(p, BasicFileAttributeView.class).readAttributes();
                java.util.Date dd = new java.util.Date(new File(file.getAbsolutePath()).lastModified());
                java.util.Date today = new java.util.Date();
                System.out.println("\n");
                if(isSameDay(dd,today) && file.getName().startsWith(fileNameStartPattern) && FilenameUtils.getExtension(file.getName()).equals(extension))
                {
                    //logger.debug("SUCCESS - File Date: "+dd.toString()+" Today: "+today +" File: "+file.getName()+" Extension: "+FilenameUtils.getExtension(file.getName()).toString());
                    outputFileStringBuilder = new StringBuilder("");
                    logger.debug("Moving File: "+file.getName()+" to Location: "+tarDirName);
                    outputFileStringBuilder.append(tarDirName)
                            .append(file.getName());
                    FileUtils.copyFile(file, new File(outputFileStringBuilder.toString()));
                    //FileUtils.moveFile(sourceFile,new File(outputFileStringBuilder.toString()));
                }
                else {
                    logger.debug("FAILURE - File Date: "+dd.toString()+" Today: "+today +" File: "+file.getName()+" Extension: "+FilenameUtils.getExtension(file.getName()).toString());
                }

            }
        }
        return true;
    }



    public static boolean isSameDay(Date date1, Date date2) {
        // Strip out the time part of each date.
        long julianDayNumber1 = date1.getTime() / MILLIS_PER_DAY;
        long julianDayNumber2 = date2.getTime() / MILLIS_PER_DAY;

        // If they now are equal then it is the same day.
        return julianDayNumber1 == julianDayNumber2;
    }
}
