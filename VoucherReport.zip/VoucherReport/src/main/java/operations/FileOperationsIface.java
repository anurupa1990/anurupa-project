package operations;

import java.io.IOException;

public interface FileOperationsIface {
    public abstract String getPropValues() throws IOException;
    public abstract String qualifyFileNameWithDateString(String outFileAbsolutePath);
    public abstract void moveProcessedFiles(String sourceDirectoryPath,String processedDirectoryPath) throws IOException;
}
