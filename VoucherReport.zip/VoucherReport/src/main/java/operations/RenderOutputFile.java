package operations;

import model.VoucherModel;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

/**
 * Created by etushch on 9/8/2017.
 */
public class RenderOutputFile {
    private Set<String> denominationKeySetRegularFaceValue;
    private Set<String> denominationKeySetComboFaceValue;
    private Set<String> denominationKeySetDataFaceValue;
    private Map<Integer, Integer> V1CountMap;
    private Map<Integer, Integer> v1CountMap;
    private Map<Integer, Integer> V2CountMap;
    private Map<Integer, Integer> v2CountMap;
    private Map<Integer, Integer> VJCountMap;
    private Map<Integer, Integer> VjCountMap;
    private Map<Integer, Integer> vJCountMap;
    private Map<Integer, Integer> vjCountMap;
    private Map<Integer, Integer> V3CountMap;
    private Map<Integer, Integer> v3CountMap;
    private Map<Integer, Integer> V4CountMap;
    private Map<Integer, Integer> v4CountMap;
    private int V1Count, v1Count, V2Count, v2Count, VJCount, VjCount, vJCount,vjCount, v3Count, V3Count, v4Count, V4Count;
    private StringBuilder simmonSB;

    public RenderOutputFile(){
        this.denominationKeySetRegularFaceValue = new java.util.HashSet<String>();
        this.denominationKeySetComboFaceValue = new java.util.HashSet<String>();
        this.denominationKeySetDataFaceValue = new java.util.HashSet<String>();
        this.V1CountMap = new java.util.TreeMap<Integer, Integer>();
        this.v1CountMap = new java.util.TreeMap<Integer, Integer>();
        this.V2CountMap = new java.util.TreeMap<Integer, Integer>();
        this.v2CountMap = new java.util.TreeMap<Integer, Integer>();
        this.VJCountMap = new java.util.TreeMap<Integer, Integer>();
        this.VjCountMap = new java.util.TreeMap<Integer, Integer>();
        this.vJCountMap = new java.util.TreeMap<Integer, Integer>();
        this.vjCountMap = new java.util.TreeMap<Integer, Integer>();
        this.V3CountMap = new java.util.TreeMap<Integer, Integer>();
        this.v3CountMap = new java.util.TreeMap<Integer, Integer>();
        this.V4CountMap = new java.util.TreeMap<Integer, Integer>();
        this.v4CountMap = new java.util.TreeMap<Integer, Integer>();
        simmonSB = new StringBuilder("");
    }

    private void renderRegularFaceValue(SiminnVoucherOperations vOps){
        for (String s : denominationKeySetRegularFaceValue) {
            V1Count=v1Count=V2Count=v2Count=VJCount=VjCount=vJCount=vjCount=0;
            for (VoucherModel vm : vOps.getVoucherRegularFaceValueList()) {
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("V1")) {
                        V1Count += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("v1")) {
                        v1Count += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("V2")) {
                        V2Count += 1;
                    }
                }
/*Bug Fix -Tushar */
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("v2")) {
                        v2Count += 1;
                    }
                }
/*Bug Fix -Tushar */
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("VJ")) {
                        VJCount += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("Vj")) {
                        VjCount += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("vJ")) {
                        vJCount += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("vj")) {
                        vjCount += 1;
                    }
                }
            }

            if(V1Count>0)
                V1CountMap.put(Integer.parseInt(s), V1Count);

            if(v1Count>0)
                v1CountMap.put(Integer.parseInt(s), v1Count);

            if(V2Count>0)
                V2CountMap.put(Integer.parseInt(s), V2Count);

            if(v2Count>0)
                v2CountMap.put(Integer.parseInt(s), v2Count);

            if(VJCount>0)
                VJCountMap.put(Integer.parseInt(s), VJCount);

            if(VjCount>0)
                VjCountMap.put(Integer.parseInt(s), VjCount);

            if(vJCount>0)
                vJCountMap.put(Integer.parseInt(s), vJCount);

            if(vjCount>0)
                vjCountMap.put(Integer.parseInt(s), vjCount);
        }

        simmonSB.append("-----------------------------------------------------------------------------\n");
        simmonSB.append("Available Voucher Report\n");
        simmonSB.append("Generated at:  ");
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        simmonSB.append(dateFormat.format(date).toString());
        simmonSB.append("\n");
        simmonSB.append("-----------------------------------------------------------------------------\n");
        simmonSB.append("\n\n");
        simmonSB.append("Regular FACE-VALUE[kr]       VG               NUM              Total value[kr]\n");
        simmonSB.append("---------------------------------------------------------------------------------\n");

        simmonSB = Utility.populateStringBufferForVoucherElement(V1CountMap, simmonSB, "V1");
        simmonSB = Utility.populateStringBufferForVoucherElement(v1CountMap, simmonSB, "v1");
        simmonSB = Utility.populateStringBufferForVoucherElement(VJCountMap, simmonSB, "VJ");
        simmonSB = Utility.populateStringBufferForVoucherElement(VjCountMap, simmonSB, "Vj");
        simmonSB = Utility.populateStringBufferForVoucherElement(vJCountMap, simmonSB, "vJ");
        simmonSB = Utility.populateStringBufferForVoucherElement(vjCountMap, simmonSB, "vj");
        simmonSB = Utility.populateStringBufferForVoucherElement(V2CountMap, simmonSB, "V2");
        simmonSB = Utility.populateStringBufferForVoucherElement(v2CountMap, simmonSB, "v2");
    }

    private void renderComboFaceValue(SiminnVoucherOperations vOps){
        for (String s : denominationKeySetComboFaceValue) {
            //System.out.println("Key: " + s);
            V3Count = v3Count = 0;
            for (VoucherModel vm : vOps.getVoucherComboFaceValueList()) {
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("V3")) {
                        V3Count += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("v3")) {
                        v3Count += 1;
                    }
                }
            }
            if(V3Count>0)
                V3CountMap.put(Integer.parseInt(s), V3Count);

            if(v3Count>0)
                v3CountMap.put(Integer.parseInt(s), v3Count);
        }

        simmonSB.append("\n\n\n\n\n");
        simmonSB.append("Combo FACE-VALUE[kr]         VG               NUM              Total value[kr]\n");
        simmonSB.append("---------------------------------------------------------------------------------\n");

        simmonSB = Utility.populateStringBufferForVoucherElement(V3CountMap, simmonSB, "V3");
        simmonSB = Utility.populateStringBufferForVoucherElement(v3CountMap, simmonSB, "v3");
    }

    private void renderDataFaceValue(SiminnVoucherOperations vOps){
        for (String s : denominationKeySetDataFaceValue) {
            //System.out.println("Key: " + s);
            V4Count = v4Count = 0;
            for (VoucherModel vm : vOps.getVoucherDataFaceValueList()) {
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("V4")) {
                        V4Count += 1;
                    }
                }
                if (vm.getValue().equalsIgnoreCase(s)) {
                    if (vm.getVoucher_group().equals("v4")) {
                        v4Count += 1;
                    }
                }
            }
            if(V4Count>0)
                V4CountMap.put(Integer.parseInt(s), V4Count);

            if(v4Count>0)
                v4CountMap.put(Integer.parseInt(s), v4Count);
        }

        simmonSB.append("\n\n\n\n\n");
        simmonSB.append("Data FACE-VALUE[MB]          VG               NUM              Total value[MB]\n");
        simmonSB.append("---------------------------------------------------------------------------------\n");

        simmonSB = Utility.populateStringBufferForVoucherElement(V4CountMap, simmonSB, "V4");
        simmonSB = Utility.populateStringBufferForVoucherElement(v4CountMap, simmonSB, "v4");

        /*
        for (Map.Entry<String, Integer> entry : V4CountMap.entrySet()) {
            String key = entry.getKey().toString();
            Integer value = entry.getValue();
            Integer intKey = Integer.parseInt(key);
            Integer CalValue = intKey*value;
            String ss = String.format("                %5d        V4           %5d           %5d",intKey,value,CalValue);
            simmonSB.append(ss);
            simmonSB.append("\n");
        }

        for (Map.Entry<String, Integer> entry : v4CountMap.entrySet()) {
            String key = entry.getKey().toString();
            Integer value = entry.getValue();
            Integer intKey = Integer.parseInt(key);
            Integer CalValue = intKey*value;
            String ss = String.format("                %5d        v4           %5d           %5d",intKey,value,CalValue);
            simmonSB.append(ss);
            simmonSB.append("\n");
        }*/
    }

    public void generateOutputFile(SiminnVoucherOperations vOps, String FILENAME) {
        BufferedWriter bw = null;
        FileWriter fw = null;

        for (VoucherModel vm:vOps.getVoucherRegularFaceValueList()
             ) {
            this.denominationKeySetRegularFaceValue.add(vm.getValue());
        }

        for (VoucherModel vm: vOps.getVoucherComboFaceValueList()
             ) {
            this.denominationKeySetComboFaceValue.add(vm.getValue());
        }

        for (VoucherModel vm: vOps.getVoucherDataFaceValueList()
             ) {
            this.denominationKeySetDataFaceValue.add(vm.getValue());
        }

        renderRegularFaceValue(vOps);
        renderComboFaceValue(vOps);
        renderDataFaceValue(vOps);

        try {
            fw = new FileWriter(FILENAME);
            bw = new BufferedWriter(fw);
            bw.write(simmonSB.toString());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

}
