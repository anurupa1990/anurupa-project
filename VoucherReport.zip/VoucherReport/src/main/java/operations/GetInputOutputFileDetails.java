package operations;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import au.com.bytecode.opencsv.bean.CsvToBean;
import model.VoucherModel;
import operations.FileOperationsIface;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.xml.soap.SOAPPart;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.*;

public class GetInputOutputFileDetails implements FileOperationsIface {
    private static Log logger = LogFactory.getLog(GetInputOutputFileDetails.class);
    private String result;
    private InputStream inputStream;
    private String configFileAbsolutePath;
    private static String propertyFileName = "config.properties";
    private StringBuilder generatedOutputFile;
    private String processedDirectoryPath;
    private String ProcessedFilePath;
    private StringBuilder outputFileStringBuilder;

    public GetInputOutputFileDetails() {
        result = null;
        inputStream = null;
        configFileAbsolutePath = null;
        outputFileStringBuilder = new StringBuilder("");
        generatedOutputFile = new StringBuilder("");
    }

    @Override
    public String getPropValues() throws IOException {
        try {
            Properties prop = new Properties();
            inputStream = getClass().getClassLoader().getResourceAsStream(propertyFileName);

            if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + propertyFileName + "' not found in the classpath");
            }
            // get the property value and print it out
            configFileAbsolutePath = prop.getProperty("INI_LOCATION");
            System.out.println("result:" + configFileAbsolutePath);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            inputStream.close();
        }
        return configFileAbsolutePath;
    }

    @Override
    public String qualifyFileNameWithDateString(String outFileAbsolutePath){
        generatedOutputFile = null;
        generatedOutputFile = new StringBuilder("");
        generatedOutputFile = generatedOutputFile.append(outFileAbsolutePath).
                                                  append("_").
                                                  append(new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss").format(new Date()).toString()).
                                                  append(".RPT");
        logger.debug("File Absolute Path: "+outFileAbsolutePath);
        logger.debug("File Qualified Name(With Absolute path): "+generatedOutputFile.toString());
        return generatedOutputFile.toString();
    }

    @Override
    public void moveProcessedFiles(String sourceDirectoryPath,String processedDirectoryPath)throws IOException
    {
        Collection<File> sourceFileList = FileUtils.listFiles(new File(sourceDirectoryPath), null, false);

        for (File sourceFile:sourceFileList)
        {
            outputFileStringBuilder = null;
            outputFileStringBuilder = new StringBuilder("");
            if(sourceFile.isFile()) {
                logger.debug("Moving File: "+sourceFile.getName()+" to Location: "+processedDirectoryPath);
                outputFileStringBuilder.append(processedDirectoryPath)
                        .append(sourceFile.getName())
                        .append("_PROCESSED_")
                        .append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()).toString());
                //FileUtils.copyFile(sourceFile, new File(outputFileStringBuilder.toString()));
                FileUtils.moveFile(sourceFile,new File(outputFileStringBuilder.toString()));
            }
        }
    }
}


