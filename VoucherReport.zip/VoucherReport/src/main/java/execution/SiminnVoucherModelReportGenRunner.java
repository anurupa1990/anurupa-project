package execution;

import operations.GetInputOutputFileDetails;
import operations.RenderOutputFile;
import operations.SiminnVoucherOperations;
import operations.Utility;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.*;
import java.util.Date;
import java.util.Properties;

/**
 * Created by etushch on 9/7/2017.
 */
public class SiminnVoucherModelReportGenRunner {
    private static Log logger = LogFactory.getLog(SiminnVoucherModelReportGenRunner.class);
    private static String CONFIGFILENAME = "./siminn_voucher_project.conf";

    public static void main(String[] args) throws IOException, InterruptedException {
        SiminnVoucherOperations ops = new SiminnVoucherOperations();
        RenderOutputFile renOf = new RenderOutputFile();
        GetInputOutputFileDetails prop = new GetInputOutputFileDetails();

        Properties property = new Properties();
        InputStream confFilePath = null;
        String baseDirectory = null;
        String inputDir= null;
        String outputDir= null;
        String processedDir = null;
        String outputFileName=null;
        String rejectedFileName = null;
        String rejectedDir=null;
        String outputFilePrefix = null;
        String rejectFilePrefix = null;
        String reportSourceDirectory="/var/opt/vs/main/reports/done";
        //String reportSourceDirectory="C:\\Java_Project\\VoucherReport\\out\\artifacts\\VoucherReport_jar\\done";
        String fileNameStartPattern="REPORT_DETAILS_";
        String fileExtension = "RPT";
        System.out.println("Start Timestamp: "+new Date().toString());
        StringBuilder dirStringBuilder = new StringBuilder("");
        StringBuilder outputFileStringBuilder = new StringBuilder("");
        StringBuilder rejectedFileStringBuilder = new StringBuilder("");
        baseDirectory = System.getenv("SIMINN_VOUCHER_HOME");
        //baseDirectory = "C:\\Tushar\\Ericsson_Work\\Project\\Simmon\\Input";
        logger.debug("SIMINN VOUCHER REPORT --- Log File");
        logger.debug("Generation Date: "+new java.util.Date().toString());
        logger.debug("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        logger.debug("Environment Variable: "+baseDirectory);
        logger.debug("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

        try {
            logger.debug("Started Processing ...........");
            logger.debug("Reading Config File: "+CONFIGFILENAME);
            confFilePath = new FileInputStream(CONFIGFILENAME);
            // get the property value and print it out
            property.load(confFilePath);

            dirStringBuilder.append(baseDirectory).append("/").append(property.getProperty("INPUT_DIR")).append("/");
            inputDir = dirStringBuilder.toString();
            dirStringBuilder = new StringBuilder("");

            dirStringBuilder.append(baseDirectory).append("/").append(property.getProperty("OUTPUT_DIR")).append("/");
            outputDir = dirStringBuilder.toString();
            dirStringBuilder = new StringBuilder("");

            dirStringBuilder.append(baseDirectory).append("/").append(property.getProperty("PROCESSED_DIR")).append("/");
            processedDir = dirStringBuilder.toString();
            dirStringBuilder = new StringBuilder("");

            dirStringBuilder.append(baseDirectory).append("/").append(property.getProperty("REJECTED_DIR")).append("/");
            rejectedDir = dirStringBuilder.toString();
            dirStringBuilder = new StringBuilder("");

            outputFilePrefix = property.getProperty("OUTFILE_PREFIX");
            rejectFilePrefix = property.getProperty("REJECTED_FILE_PREFIX");
            logger.debug("\nInput Directory: "+inputDir.toString()+"\n"+
                                   "Output Directory: "+outputDir.toString()+"\n"+
                                   "Processed Dirctory: "+processedDir.toString()+"\n"+
                                   "Rejected Directory: "+rejectedDir.toString()+"\n"+
                                   "Output File Prefix: "+outputFilePrefix.toString()+"\n"+
                                   "Rejected File Prefix: "+rejectFilePrefix.toString());
        } catch (FileNotFoundException ex) {
            logger.error("Config File: "+CONFIGFILENAME+" Not Found -- Aborting !!!!");
            logger.info("Please verify your config file: "+CONFIGFILENAME);
            ex.printStackTrace();
        } finally {
            if (confFilePath != null) {
                try {
                    logger.info("Closing config file handle .....");
                    confFilePath.close();
                } catch (IOException e) {
                    logger.error("Error while closing config file handle !!! Aborting !!!!");
                    e.printStackTrace();
                }
            }
        }
        //logger.debug("Cleaning Output Directory .....");
        //Utility.cleanEnvironment(outputDir);
        //logger.debug("Cleaning Rejected Directory .....");
        //Utility.cleanEnvironment(rejectedDir);
        //logger.debug("Cleaning Log Directory ");
        logger.debug("Copying Source Files ....\n");
        try {
            Utility.copySourceFiles(reportSourceDirectory, inputDir.toString(), fileNameStartPattern, fileExtension);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        logger.debug("Preparing Environment and doing health check ....\n");
        Thread.sleep(2000);
        logger.debug("Environment Preparation completed ....");
        if( !ops.readCSVAndPopulateModelElement(inputDir.toString())){
            logger.debug("End Timestamp: "+new Date().toString());
            logger.debug("Total Record Processed: "+ops.totalRecordProcessed());
            System.exit(0);
        }

        rejectedFileStringBuilder.append(rejectedDir.toString()).append(rejectFilePrefix.toString());
        rejectedFileName=prop.qualifyFileNameWithDateString(rejectedFileStringBuilder.toString());
        logger.debug("Generated Rejected File Name: "+rejectedFileName);
        logger.debug("Validating Records for Mandatory Field Presence ...");
        ops.renderVoucherValidList(rejectedFileName);
        logger.debug("Filtering Master List ...");
        ops.filterVoucherValidList();
        logger.debug("Master List Filtration Completed ...");
        logger.debug("Rendering Filtered List based on Voucher Code ...");
        ops.renderFilterList();
        ops.dumpVoucherModel();
        outputFileStringBuilder.append(outputDir.toString()).append(outputFilePrefix.toString());
        outputFileName = prop.qualifyFileNameWithDateString(outputFileStringBuilder.toString());
        logger.debug("Populating Output File Content ....");
        renOf.generateOutputFile(ops, outputFileName);
        logger.debug("Output File: "+outputFileName+" generated successfully ...");
        logger.debug("Moving processed input files to Processed Directory ...");
        prop.moveProcessedFiles(inputDir.toString(), processedDir.toString());
        logger.debug("File movement completed ...");
        logger.debug("End Timestamp: "+new Date().toString());
        logger.debug("\n\n\n\n\n");
        logger.debug("Total Record Processed: "+ops.totalRecordProcessed());
        logger.debug("Total Records REJECTED: "+ops.totalRejectedRecords());
        logger.debug("Total Records Filtered Out: "+ops.totalFilteredRecords());
        logger.debug("Total Regular FACE Value Voucher Processed: "+ops.totalRegularRecordProcessed());
        logger.debug("Total Combo FACE Value Voucher Processed: "+ops.totalComboRecordProcessed());
        logger.debug("Total DATA FACE Value Voucher Processed: "+ops.totalDataRecordProcessed());
        logger.debug("\n\n\n");
        logger.debug("Output File Generated: "+outputFileName);
        logger.debug("\n\n\n");
        logger.debug("Operation Completed ... Exiting !!!");
    }
}
