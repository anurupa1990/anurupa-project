-- -----------------------------------------------------------------------------
--
--
--       Purpose: it is used for Deleting TRACK from MIG_PROCESS
--
-- -----------------------------------------------------------------------------
BEGIN
	DELETE FROM DMFADM.MIG_PROCESS WHERE TRACK='NK_INDOSAT_REQ03_SOI';
	COMMIT;
        
EXCEPTION
    WHEN OTHERS THEN
	    ROLLBACK;
        DBMS_OUTPUT.PUT_LINE ('Exception occured');
		DBMS_OUTPUT.PUT_LINE (SQLERRM);

END;
/

