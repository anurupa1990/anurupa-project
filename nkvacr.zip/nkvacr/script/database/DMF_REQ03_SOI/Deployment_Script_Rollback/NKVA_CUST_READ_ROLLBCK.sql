-- -----------------------------------------------------------------------------
--
--
--       Purpose: it is used for Deleting from MODULES and MODULES_HIERARCHY
--
-- -----------------------------------------------------------------------------
DELETE FROM SYSADM.MODULES_HIERARCHY WHERE CHILD = 'CMSNKVCR';
DELETE FROM SYSADM.MODULES WHERE MODULENAME = 'CMSNKVCR';

commit;