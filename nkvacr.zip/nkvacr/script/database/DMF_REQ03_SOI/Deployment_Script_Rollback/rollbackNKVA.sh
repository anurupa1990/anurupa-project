#! /bin/sh
if [ ! -d $BSCS_WORKDIR ]
then
  echo "$BSCS_WORKDIR dir not found, complete the rollback manually."
  exit 1
fi


ORACLE_SID=INDONKD
ORACLE_USER=SYSADM
ORACLE_PASSWD=SYSADM

export ORACLE_SID

export ORACLE_USER

export ORACLE_PASSWD



export ROLL_HOME=$BSCS_WORKDIR/INDOSAT_REQ03/nkvacr-1.0/nk-vacr-database/DMF_REQ03_SOI/Deployment_Script_Rollback

LOGFILE=$ROLL_HOME/nk_log_file_$$.log

sqlplus $ORACLE_USER/$ORACLE_PASSWD@$ORACLE_SID << eof_disp > $LOGFILE
	@$ROLL_HOME/ROLLBACK_VACR_SOI.sql
	@$ROLL_HOME/NKVA_CUST_READ_ROLLBCK.sql
	@$ROLL_HOME/NKVA_MIGPROC_ROLLBACK.sql
	commit;
eof_disp


echo "Rollback done"
