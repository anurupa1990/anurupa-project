-- -----------------------------------------------------------------------------
--
--
--       Purpose: MODULE HIERARCHY Script
--
-- -----------------------------------------------------------------------------
BEGIN
        Migration.StartScript
        (
                piosScriptName       =>  '07_NK_VA_CUST_READ.sql'
				,piosTrack            => 'NK_INDOSAT_REQ03_SOI'
				,piosScriptVersion    => 'NK0003'
				,piosLevelName        => 'IST_NK_REQ03_SOI_20170510'
				,piosReleaseName      => 'IST_NK_REQ03_SOI_0001'
				,piosComponentName    => 'DAB'
				,piobReexecutableInd  => FALSE
				,piosDescription      => 'Script to MODULE Hirarchy'
        );
        
END;
/

------------------------------------------------------------
-- Assigning the modules to CMSCMDS
------------------------------------------------------------
   
Insert into SYSADM.MODULES
   (MODULENAME, MODULENUMBER, DESCRIPTION, ENTDATE, REC_VERSION, 
    PERM_CODE, SOI_COMMAND, MAX_USER_RIGHTS)
SELECT 'NKAIMCM', 0, 'Non Kernel Application SOI', SYSDATE, 0, 'NKAIMCM_AccessRights', 'X', 'W' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM SYSADM.MODULES WHERE MODULENAME = 'NKAIMCM');

Insert into SYSADM.MODULES_HIERARCHY
   (PARENT, CHILD, GRPPERM)
SELECT 'CMSCMDS', 'NKAIMCM', 2147483647 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM SYSADM.MODULES_HIERARCHY WHERE PARENT = 'CMSCMDS' AND CHILD='NKAIMCM');

-----------------------------------NK_VA_CUSTOMER.READ--------------------------------------

Insert into SYSADM.MODULES
   (MODULENAME, MODULENUMBER, DESCRIPTION, ENTDATE, REC_VERSION, 
    PERM_CODE, SOI_COMMAND, MAX_USER_RIGHTS)
SELECT 'CMSNKVCR', 0, 'NK_VA_CUSTOMER.READ', SYSDATE, 0, 'NK_VA_CUSTOMER.READ', 'X', 'W' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM SYSADM.MODULES WHERE MODULENAME = 'CMSNKVCR');

Insert into SYSADM.MODULES_HIERARCHY
   (PARENT, CHILD, GRPPERM)
SELECT 'NKAIMCM', 'CMSNKVCR', 2147483647 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM SYSADM.MODULES_HIERARCHY WHERE PARENT = 'NKAIMCM' AND CHILD='CMSNKVCR');


COMMIT;

-- Finish SQL script execution.
BEGIN
        Migration.FinishScript
        (
                piosScriptName => '07_NK_VA_CUST_READ.sql'
        );
END;
/