   -- -----------------------------------------------------------------------------
--
--
--       Purpose: Script for ISAT_VA_CUST_TYPE_PRGCODE table creation
--
-- -----------------------------------------------------------------------------

BEGIN
        Migration.StartScript
        (
                piosScriptName       => '03_ISAT_VA_CUST_TYPE_PRGCODE.sql'
				,piosTrack            => 'NK_INDOSAT_REQ03_SOI'
				,piosScriptVersion    => 'NK0003'
				,piosLevelName        => 'IST_NK_REQ03_SOI_20170510'
				,piosReleaseName      => 'IST_NK_REQ03_SOI_0001'
				,piosComponentName    => 'DAB'
				,piobReexecutableInd  => FALSE
				,piosDescription      => 'Script to ISAT_VA_CUST_TYPE_PRGCODE table creation'
        );
        
END;
/
   
   CREATE TABLE NKADM.ISAT_VA_CUST_TYPE_PRGCODE 
   (	SL_NUMBER NUMBER(10,0), 
	CUSTOMER_TYPE VARCHAR2(30), 
	PRGCODE VARCHAR2(10),
	CONSTRAINT PK_VA_CUST_TYPE_PRGCODE PRIMARY KEY (SL_NUMBER)
   );

   COMMENT ON COLUMN NKADM.ISAT_VA_CUST_TYPE_PRGCODE.SL_NUMBER IS 'Serial Number of the record it is Primary Key';
   COMMENT ON COLUMN NKADM.ISAT_VA_CUST_TYPE_PRGCODE.CUSTOMER_TYPE IS 'Customer type Individual or Corporate';
   COMMENT ON COLUMN NKADM.ISAT_VA_CUST_TYPE_PRGCODE.PRGCODE IS 'PRGCODE defining customer type for Corporate customer PRGCODE=4 , if other then Individual customer';

   CREATE OR REPLACE PUBLIC SYNONYM ISAT_VA_CUST_TYPE_PRGCODE FOR NKADM.ISAT_VA_CUST_TYPE_PRGCODE ; 
   GRANT ALL ON NKADM.ISAT_VA_CUST_TYPE_PRGCODE TO BSCS_ROLE;
	
BEGIN	
	INSERT INTO NKADM.ISAT_VA_CUST_TYPE_PRGCODE (SL_NUMBER, CUSTOMER_TYPE, PRGCODE) 
	SELECT 1, 'Corporate', '4' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM NKADM.ISAT_VA_CUST_TYPE_PRGCODE WHERE SL_NUMBER = 1); 
	COMMIT;
   EXCEPTION 
		WHEN OTHERS THEN
		ROLLBACK;

END;
/
   
-- Finish SQL script execution.   
BEGIN
        Migration.FinishScript
        (
                piosScriptName => '03_ISAT_VA_CUST_TYPE_PRGCODE.sql'
        );
END;
/   