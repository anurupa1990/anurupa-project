-- -----------------------------------------------------------------------------
--
--
--       Purpose: Trigger for Insert into INFO_CUST_TEXT
--
-- -----------------------------------------------------------------------------

BEGIN
        Migration.StartScript
        (
                piosScriptName       => '04_INSERT_INFO_CUST_TEXT_VA.sql'
				,piosTrack            => 'NK_INDOSAT_REQ03_SOI'
				,piosScriptVersion    => 'NK0003'
				,piosLevelName        => 'IST_NK_REQ03_SOI_20170510'
				,piosReleaseName      => 'IST_NK_REQ03_SOI_0001'
				,piosComponentName    => 'DAB'
				,piobReexecutableInd  => FALSE
				,piosDescription      => 'Script to create trigger for insertion'
        );
        
END;
/

create or replace TRIGGER INSERT_INFO_CUST_TEXT_VA 
--AFTER INSERT ON INFO_CUST_TEXT 
BEFORE INSERT ON INFO_CUST_TEXT 
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW

/*Declare the variables  */
DECLARE
  --pragma autonomous_transaction; 
  pl_paymntresp VARCHAR2(1 BYTE);
  pl_customer_id CUSTOMER_ALL.CUSTOMER_ID%type;
  pl_Primary_Doc_Currency BILLING_ACCOUNT.PRIMARY_DOC_CURRENCY%type;
  pl_currency VARCHAR2(3 BYTE);
  pl_text01 VARCHAR2(14 BYTE);
  pl_text02 VARCHAR2(14 BYTE);
  pl_prgcode CUSTOMER_ALL.prgcode%type;
  pl_cstype VARCHAR2(1 BYTE);
  pl_corpo_count NUMBER(3,0);
  pl_usd_fc_id NUMBER(38,0);
  pl_idr_fc_id NUMBER(38,0);

  
/*Functionality of Trigger begins */
BEGIN  
   BEGIN
     select PRIMARY_DOC_CURRENCY into pl_Primary_Doc_Currency from BILLING_ACCOUNT where  CUSTOMER_ID = :new.CUSTOMER_ID;
       DBMS_OUTPUT.PUT_LINE('pl_Primary_Doc_Currency ');
    EXCEPTION WHEN NO_DATA_FOUND THEN
      pl_Primary_Doc_Currency := NULL;
    END;

    BEGIN
      select customer_id,cstype,prgcode,Paymntresp INTO pl_customer_id,pl_cstype,pl_prgcode,pl_paymntresp from CUSTOMER_ALL where CUSTOMER_ID = :new.CUSTOMER_ID;
      DBMS_OUTPUT.PUT_LINE('pl_Primary_Doc_Currency '||pl_Primary_Doc_Currency);
      EXCEPTION WHEN NO_DATA_FOUND THEN
      RAISE;
    END;

    BEGIN
      select COUNT(*) into pl_corpo_count from NKADM.ISAT_VA_CUST_TYPE_PRGCODE where CUSTOMER_TYPE = 'Corporate' and PRGCODE = pl_prgcode;
      DBMS_OUTPUT.PUT_LINE('pl_corpo_count '||pl_corpo_count);
    END;
    
    
    BEGIN
      select FC_ID into pl_usd_fc_id from forcurr where FCCODE='USD';
      select FC_ID into pl_idr_fc_id from forcurr where FCCODE='IDR';
      DBMS_OUTPUT.PUT_LINE('pl_Primary_Doc_Currency '||pl_Primary_Doc_Currency);
      EXCEPTION WHEN NO_DATA_FOUND THEN
          RAISE;
    END;
    
     
 /*  here customer should be acive ,payment reponsible and  have Biling account */
  if(pl_cstype='a' and pl_paymntresp IS NOT NULL  and pl_Primary_Doc_Currency IS NOT NULL) --start if-1
  then
DBMS_OUTPUT.PUT_LINE('Primary_Doc_Currency,paymntresp and csactivated IS NOT NULL ');

      /*   ************** for individual customer  ******************* */
        if(pl_corpo_count = 0)-- individual
        then
              if(pl_Primary_Doc_Currency = pl_idr_fc_id) -- for IDR, FC_ID=44
              then
                  --TEXT01 with 9820 xxxxxxxxxx 
                  pl_text01 := CONCAT( '9820', LPAD(CITI_IDR_VA_SEQ.nextVAL,10,0));
                  pl_text02 := null;
              end if;
              
              if(pl_Primary_Doc_Currency = pl_usd_fc_id) --for USD, FC_ID = 19
                  then 
                     -- TEXT01 with 9821 xxxxxxxxxx
                      pl_text01 := CONCAT( '9821', LPAD(CITI_USD_VA_SEQ.nextVAL,10,0));
                       pl_text02 := null;
              end if;
              
          DBMS_OUTPUT.PUT_LINE('individual pl_text01'||pl_text01); 
        end if; -- individual
       
       /* **************** for corporate customer ****************** */

          if(pl_corpo_count > 0)--corporate
          then
              if(pl_Primary_Doc_Currency = pl_idr_fc_id) --for IDR,  FC_ID = 44
              then
                  --TEXT01 with 88900 30 xxxxxxx
                  pl_text01 := CONCAT( '9820', LPAD(CITI_IDR_VA_SEQ.nextVAL,10,0));
                  pl_text02 := CONCAT( '8890030', LPAD(MDR_IDR_VA_SEQ.nextVAL,7,0));
               end if;
               
              if(pl_Primary_Doc_Currency = pl_usd_fc_id) --for USD, FC_ID=19
              then 
                  -- TEXT01 with 88901 30 xxxxxxx
                  pl_text01 := CONCAT( '9821', LPAD(CITI_USD_VA_SEQ.nextVAL,10,0));
                  pl_text02 := CONCAT( '8890130', LPAD(MDR_USD_VA_SEQ.nextVAL,7,0)); 
              end if;
             
             DBMS_OUTPUT.PUT_LINE('For Coporate pl_text01='||pl_text01||'  pl_text02='||pl_text02);
       end if; --corporate
       
       -- update INFO_CUST_TEXT
        if(pl_text01 is not null and LENGTH(pl_text01)= 14)
        then
              :NEW.TEXT01 := pl_text01; 
              :NEW.TEXT02 := pl_text02;

             DBMS_OUTPUT.PUT_LINE('VA for Individual Customer Updation SUCCESS');
        end if;
   end if ; --end if-1 
   
    exception
          when others
          then
           DBMS_OUTPUT.PUT_LINE('********** OTHER ERROR OCCURED ************** '||sqlcode||' '||sqlerrm);
          raise;
END;
/

-- Finish SQL script execution.
BEGIN
        Migration.FinishScript
        (
                piosScriptName => '04_INSERT_INFO_CUST_TEXT_VA.sql'
        );
END;
/
