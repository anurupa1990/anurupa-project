-- -----------------------------------------------------------------------------
--
--
--       Purpose: Trigger for insert into Billing Account
--
-- -----------------------------------------------------------------------------

BEGIN
        Migration.StartScript
        (
                piosScriptName       => '05_INSERT_BILLING_ACCOUNT_VA.sql'
				,piosTrack            => 'NK_INDOSAT_REQ03_SOI'
				,piosScriptVersion    => 'NK0003'
				,piosLevelName        => 'IST_NK_REQ03_SOI_20170510'
				,piosReleaseName      => 'IST_NK_REQ03_SOI_0001'
				,piosComponentName    => 'DAB'
				,piobReexecutableInd  => FALSE
				,piosDescription      => 'Script to create trigger for insert into Billing Account'
        );
        
END;
/
CREATE OR REPLACE TRIGGER INSERT_BILLING_ACCOUNT_VA 
AFTER INSERT ON BILLING_ACCOUNT
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW

WHEN(NEW.PRIMARY_FLAG IS NOT NULL)
/*Declare the variables  */
DECLARE
  --pragma autonomous_transaction;
  pl_paymntresp VARCHAR2(1 BYTE);
  pl_customer_id CUSTOMER_ALL.CUSTOMER_ID%type;
  pl_Primary_Doc_Currency BILLING_ACCOUNT.PRIMARY_DOC_CURRENCY%type := :NEW.Primary_Doc_Currency;
  pl_currency VARCHAR2(3 BYTE);
  pl_text01 VARCHAR2(14 BYTE);
  pl_text02 VARCHAR2(14 BYTE);
  pl_prgcode CUSTOMER_ALL.prgcode%type;
  pl_cstype VARCHAR2(1 BYTE);
  pl_corpo_count NUMBER(3,0);
  pl_usd_fc_id NUMBER(38,0);
  pl_idr_fc_id NUMBER(38,0);
  
  L_RECORD_EXIST NUMBER(38,0);


BEGIN
    SELECT COUNT(*) INTO L_RECORD_EXIST FROM INFO_CUST_TEXT WHERE CUSTOMER_ID = :NEW.CUSTOMER_ID;

IF(L_RECORD_EXIST > 0 ) THEN 

   BEGIN
      SELECT CUSTOMER_ID,CSTYPE,PRGCODE,PAYMNTRESP INTO PL_CUSTOMER_ID,PL_CSTYPE,PL_PRGCODE,PL_PAYMNTRESP From CUSTOMER_ALL WHERE CUSTOMER_ID = :new.CUSTOMER_ID;
      EXCEPTION WHEN NO_DATA_FOUND THEN
      RAISE;
    END;

    BEGIN
      select COUNT(*) into pl_corpo_count from NKADM.ISAT_VA_CUST_TYPE_PRGCODE where CUSTOMER_TYPE = 'Corporate' and PRGCODE = pl_prgcode;
      DBMS_OUTPUT.PUT_LINE('pl_corpo_count '||pl_corpo_count);
    END;
    
    BEGIN
      select FC_ID into pl_usd_fc_id from forcurr where FCCODE='USD';
      select FC_ID into pl_idr_fc_id from forcurr where FCCODE='IDR';
        EXCEPTION WHEN NO_DATA_FOUND THEN
        RAISE;
    END;
    
    IF(PL_CSTYPE = 'a' AND PL_PAYMNTRESP IS NOT NULL) THEN  --start if-1
     
      DBMS_OUTPUT.PUT_LINE('paymntresp and cstype=a');
      
            /*   ************** for individual customer  ******************* */
              if(pl_corpo_count = 0)-- individual
              then
                    if(pl_Primary_Doc_Currency = pl_idr_fc_id) -- for IDR, FC_ID=44
                    then  
                        --TEXT01 with 9820 xxxxxxxxxx 
                        pl_text01 := CONCAT( '9820', LPAD(CITI_IDR_VA_SEQ.nextVAL,10,0));
                        pl_text02 := null;
 
                    end if;
                    
                    if(pl_Primary_Doc_Currency = pl_usd_fc_id) --for USD, FC_ID = 19
                        then 
                           -- TEXT01 with 9821 xxxxxxxxxx
                            pl_text01 := CONCAT( '9821', LPAD(CITI_USD_VA_SEQ.nextVAL,10,0));
                            pl_text02 := null;
                    end if;
                    
                DBMS_OUTPUT.PUT_LINE('individual pl_text01'||pl_text01); 
     
              end if; --individual
             


             /* **************** for corporate customer ****************** */
      
                if(pl_corpo_count > 0) --corporate
                then
                    if(pl_Primary_Doc_Currency = pl_idr_fc_id) --for IDR,  FC_ID = 44
                    then
                        --TEXT01 with 88900 30 xxxxxxx
                        pl_text01 := CONCAT( '9820', LPAD(CITI_IDR_VA_SEQ.nextVAL,10,0));
                        pl_text02 := CONCAT( '8890030', LPAD(MDR_IDR_VA_SEQ.nextVAL,7,0));
                     end if;
                     
                    if(pl_Primary_Doc_Currency = pl_usd_fc_id) --for USD, FC_ID=19
                    then
                        -- TEXT01 with 88901 30 xxxxxxx
                        pl_text01 := CONCAT( '9821', LPAD(CITI_USD_VA_SEQ.nextVAL,10,0));
                        pl_text02 := CONCAT( '8890130', LPAD(MDR_USD_VA_SEQ.nextVAL,7,0)); 
                    end if;
                   
                   DBMS_OUTPUT.PUT_LINE('For Coporate pl_text01='||pl_text01||'  pl_text02='||pl_text02);
             end if;  --corporate
             
             
                  -- update INFO_CUST_TEXT
                  if(pl_text01 is not null and LENGTH(pl_text01)= 14)
                  then
               
                    UPDATE INFO_CUST_TEXT SET 
                        TEXT01 = pl_text01, 
                        TEXT02 = pl_text02
                        WHERE CUSTOMER_ID = :new.CUSTOMER_ID;
      
                   DBMS_OUTPUT.PUT_LINE('VA for Individual Customer Updation SUCCESS');
                  end if;
      END IF ; --end if-1 
END IF;
END;
/

-- Finish SQL script execution.
BEGIN
        Migration.FinishScript
        (
                piosScriptName => '05_INSERT_BILLING_ACCOUNT_VA.sql'
        );
END;
/