   -- -----------------------------------------------------------------------------
--
--
--       Purpose: Script for sequence creation
--
-- -----------------------------------------------------------------------------

BEGIN
        Migration.StartScript
        (
                piosScriptName       => '02_VA_SEQUENCE.sql'
				,piosTrack            => 'NK_INDOSAT_REQ03_SOI'
				,piosScriptVersion    => 'NK0003'
				,piosLevelName        => 'IST_NK_REQ03_SOI_20170510'
				,piosReleaseName      => 'IST_NK_REQ03_SOI_0001'
				,piosComponentName    => 'DAB'
				,piobReexecutableInd  => FALSE
				,piosDescription      => 'Script to sequence creation'
        );
        
END;
/
 CREATE SEQUENCE SYSADM.CITI_USD_VA_SEQ
  MAXVALUE 9999999999
  START WITH 1
  INCREMENT BY 1
  NOCACHE;
  
  CREATE OR REPLACE PUBLIC SYNONYM CITI_USD_VA_SEQ for SYSADM.CITI_USD_VA_SEQ;

  GRANT ALL ON SYSADM.CITI_USD_VA_SEQ to BSCS_ROLE;

  
  CREATE SEQUENCE SYSADM.CITI_IDR_VA_SEQ
  MAXVALUE 9999999999
  START WITH 1
  INCREMENT BY 1
  NOCACHE;
  
  CREATE OR REPLACE PUBLIC SYNONYM CITI_IDR_VA_SEQ for SYSADM.CITI_IDR_VA_SEQ;

  GRANT ALL ON SYSADM.CITI_IDR_VA_SEQ to BSCS_ROLE;
  
  
  
  CREATE SEQUENCE SYSADM.MDR_USD_VA_SEQ
  MAXVALUE 9999999
  START WITH 1
  INCREMENT BY 1
  NOCACHE;
  
  CREATE OR REPLACE PUBLIC SYNONYM MDR_USD_VA_SEQ for SYSADM.MDR_USD_VA_SEQ;

  GRANT ALL ON SYSADM.MDR_USD_VA_SEQ to BSCS_ROLE;
  
  
  CREATE SEQUENCE SYSADM.MDR_IDR_VA_SEQ
  MAXVALUE 9999999
  START WITH 1
  INCREMENT BY 1
  NOCACHE;
  
  CREATE OR REPLACE PUBLIC SYNONYM MDR_IDR_VA_SEQ for SYSADM.MDR_IDR_VA_SEQ;

  GRANT ALL ON SYSADM.MDR_IDR_VA_SEQ to BSCS_ROLE;
  
  -- Finish SQL script execution.   
BEGIN
        Migration.FinishScript
        (
                piosScriptName => '02_VA_SEQUENCE.sql'
        );
END;
/   
