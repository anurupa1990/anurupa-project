-- -----------------------------------------------------------------------------
--
--
--       Purpose: Insert Script
--
-- -----------------------------------------------------------------------------

BEGIN
        Migration.StartScript
        (
                piosScriptName       => '01_NKADM_USER_CREATION.sql'
				,piosTrack            => 'NK_INDOSAT_REQ03_SOI'
				,piosScriptVersion    => 'NK0003'
				,piosLevelName        => 'IST_NK_REQ03_SOI_20170510'
				,piosReleaseName      => 'IST_NK_REQ03_SOI_0001'
				,piosComponentName    => 'DAB'
				,piobReexecutableInd  => FALSE
				,piosDescription      => 'Script to create non-kernel schema NKADM'
        );
        
END;
/

BEGIN


    DECLARE
		NKADM_CNT               INTEGER := 0;
	BEGIN
		--Check existance of NKADM Schema
		SELECT COUNT(*) INTO NKADM_CNT FROM DBA_OBJECTS WHERE OWNER='NKADM';

		IF(NKADM_CNT = 0)
		THEN
			EXECUTE IMMEDIATE 'CREATE USER NKADM IDENTIFIED BY NKADM PROFILE DEFAULT ACCOUNT UNLOCK';
		END IF;
		
		-- Roles for NKADM 
		EXECUTE IMMEDIATE 'GRANT CONNECT TO NKADM';
		EXECUTE IMMEDIATE 'GRANT RESOURCE TO NKADM';
		EXECUTE IMMEDIATE 'ALTER USER NKADM DEFAULT ROLE ALL';
		-- System Privileges for NKADM 
		EXECUTE IMMEDIATE 'GRANT CREATE TABLE TO NKADM';
		EXECUTE IMMEDIATE 'GRANT CREATE SYNONYM TO NKADM';
        EXECUTE IMMEDIATE 'GRANT CREATE TRIGGER TO NKADM';
		EXECUTE IMMEDIATE 'GRANT CREATE MATERIALIZED VIEW TO NKADM';
		EXECUTE IMMEDIATE 'GRANT CREATE DATABASE LINK TO NKADM';
		EXECUTE IMMEDIATE 'GRANT ALTER ANY SNAPSHOT TO NKADM';
		EXECUTE IMMEDIATE 'GRANT CREATE SESSION, CREATE ANY TRIGGER TO NKADM';
		EXECUTE IMMEDIATE 'GRANT CREATE PUBLIC SYNONYM TO NKADM';
		EXECUTE IMMEDIATE 'GRANT DROP PUBLIC SYNONYM TO NKADM';
		EXECUTE IMMEDIATE 'GRANT UNLIMITED TABLESPACE TO NKADM';
		-- Object Privileges for NKADM 
		EXECUTE IMMEDIATE 'GRANT SELECT ANY TABLE TO NKADM';
		-- Proxy for NKADM 
		EXECUTE IMMEDIATE 'ALTER USER NKADM GRANT CONNECT THROUGH SYSADM';
	  	
	EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE ('Exception occured');
            DBMS_OUTPUT.PUT_LINE (SQLERRM);	
	END;


END;
/


-- Finish SQL script execution.
BEGIN
        Migration.FinishScript
        (
                piosScriptName => '01_NKADM_USER_CREATION.sql'
        );
END;
/
