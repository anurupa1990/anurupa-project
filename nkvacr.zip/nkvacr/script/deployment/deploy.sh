#!/bin/bash

echo "Copying resources into server."
cp -r ./lib/* $BSCS_ROOT/lib/
cp -r ./resource/* $BSCS_ROOT/resource/

echo "Deployment complete"

