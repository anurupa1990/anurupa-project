#!/bin/bash

echo "removing $BSCS_ROOT/lib/jar/cms_plugin/nkvacr-1.0.0.jar"
rm -rf $BSCS_ROOT/lib/jar/cms_plugin/nkvacr-1.0.0.jar

echo "removing NK CMS API's from $BSCS_ROOT/resource/cms/cdf/"
rm -rf $BSCS_ROOT/resource/cms/cdf/NK_VA_CUSTOMER_READ

echo "removing NK CMS PLUGIN files from $BSCS_ROOT/resource/cms/plugin/"
rm -rf $BSCS_ROOT/resource/cms/plugin/Registry_NKVaCustomerRead.xml
#rm -rf $BSCS_ROOT/resource/cms/plugin/Registry_NK_CIL.xml

#echo "removing NK CMS SOI files from $BSCS_ROOT/resource/cms/soi/"
#rm -rf $BSCS_ROOT/resource/cms/soi/NK_CMI_7.xml
#delete the api name from soi 

echo "Rollback of NK_VA_CUSTOMER.READ API is complete"

