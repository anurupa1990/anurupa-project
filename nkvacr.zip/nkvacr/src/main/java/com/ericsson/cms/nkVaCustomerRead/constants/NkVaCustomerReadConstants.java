
package com.ericsson.cms.nkVaCustomerRead.constants;

public class NkVaCustomerReadConstants {

	public static final int DIGIT_IN_VA_ID = 14;

	public static final String READ_CITY_CUSTOMER = " SELECT ICT.CUSTOMER_ID, CUSTNUM FROM INFO_CUST_TEXT ICT , CUSTOMER_ALL CA WHERE ICT.CUSTOMER_ID = CA.CUSTOMER_ID AND " +
			"TEXT01  = #VA_ID ";
	
	public static final String READ_MANDIRI_CUSTOMER = " SELECT ICT.CUSTOMER_ID, CUSTNUM FROM INFO_CUST_TEXT ICT , CUSTOMER_ALL CA WHERE ICT.CUSTOMER_ID = CA.CUSTOMER_ID " +
			"AND TEXT02  = #VA_ID ";
	 	 
	 
	 


}


