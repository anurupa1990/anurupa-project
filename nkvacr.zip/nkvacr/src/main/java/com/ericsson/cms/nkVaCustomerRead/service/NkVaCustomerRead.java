/****************************************************************************
 * Source: CustomerDetails  
 *                                    
 * Description: This is a class used to fetch corresponding customer_id for input va_id and bank                        
 *                                                                          
 *                                                                          
 * History:  |Date             |Version       |Change Description
 *               2017-04-12     1.0              Initial Version.
 *                                                                       
 * Author: Monomita Mazumdar                                               
 ****************************************************************************/

package com.ericsson.cms.nkVaCustomerRead.service;

import java.math.BigDecimal;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ericsson.cms.nkVaCustomerRead.constants.NkVaCustomerReadConstants;
import com.lhs.ccb.common.soi.ExchangeFormatFactory;
import com.lhs.ccb.common.soi.SVLObject;
import com.lhs.ccb.common.soi.SVLObjectList;
import com.lhs.ccb.func.ect.ComponentException;
import com.lhs.ccb.sfw.application.CommandVersionNotSupportedException;
import com.lhs.ccb.sfw.application.DomainServiceAdapter;
import com.lhs.ccb.sfw.application.ImplementationRegistry;
import com.lhs.ccb.sfw.application.InconsistentRegistryException;
import com.lhs.ccb.sfw.application.ServiceContext;
import com.lhs.ccb.sfw.domain.TransactionContext;
import org.eclipse.persistence.queries.DataReadQuery;
import org.eclipse.persistence.sessions.DatabaseRecord;

/**
 * This class is used to fetch corresponding customer_id for input va_id and bank
 **/
public class NkVaCustomerRead implements DomainServiceAdapter {

	private static Logger _log = Logger.getLogger("SystemLog");

	private static NkVaCustomerRead _instance;

	private String vaId;
	private String bankName;
    

	private static final String COMMAND_NAME = "NK_VA_CUSTOMER.READ";
	private static final String COMMAND_VERSION = "CMD_1_0";

	protected static final ExchangeFormatFactory xFactory = ExchangeFormatFactory
			.instance();

	private NkVaCustomerRead() {
		initialize();
	}

	public static NkVaCustomerRead getInstance() {
		if (_instance == null)
			synchronized (NkVaCustomerRead.class) {
				if (_instance == null)
					_instance = new NkVaCustomerRead();
			}
		return _instance;
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public void execute(ServiceContext pContext, String pCommandName,
			String pServiceLayerVersion, SVLObject pInput, SVLObject pOutput)
			throws CommandVersionNotSupportedException, ComponentException {

		_log.fine("Executing command :: " + COMMAND_NAME);

		// Input validation
		try {			

			_log.fine("===========Start NK_VA_CUSTOMER.READ===================");
			
			if (null == pInput.getStringValue("VA_ID")
					|| pInput.getStringValue("VA_ID").isEmpty()) {
				throw new Exception(
						"Mandatory input parameter VA_ID is missing");
			} else {
				vaId = pInput.getStringValue("VA_ID");
			}
			
			if (null == pInput.getStringValue("BANK")
					|| pInput.getStringValue("BANK").isEmpty()) {
				throw new Exception(
						"Mandatory input parameter BANK is missing");
			} else {
				bankName = pInput.getStringValue("BANK");
			}			
			
			_log.info("===========NK_VA_CUSTOMER.READ===================");
			_log.info("Input VA_ID is :" + vaId);
			_log.info("Input BANK is :" + bankName);
			_log.info("=================================================");
			
			/*
			 *  Validate input parameter VA_ID
			 */
			// VA_ID should consist of 14 digit
			String regex = "\\d+";
			
			// count number of digit in VA_ID
			int vaIdCountDigit = 0;
			for (int i = 0, len = vaId.length(); i < len; i++) {
				if (Character.isDigit(vaId.charAt(i))) {
					vaIdCountDigit++;
				}
			}

			// VA_ID should contain only digits
			if(vaId.matches(regex)){
				// VA_ID should consist of 14 digits
				if(vaIdCountDigit != NkVaCustomerReadConstants.DIGIT_IN_VA_ID) {
					throw new Exception(
							"Input parameter VA_ID should consist of 14 digit");
				}
			} else {
				throw new Exception(
						"Input parameter VA_ID should contain only digits");
			}
			
			/*
			 *  Validate input parameter BANK
			 */
			// The SQL query to fetch customer details
			String selectSql = null;
			
			/* For city bank, check prefix first, then construct select query where va_id will be searched from INFO_CUST_TEXT(TEXT01);
			 * For mandiri bank, check prefix first, then construct select query where va_id will be searched from INFO_CUST_TEXT(TEXT02)
			 */
			if(bankName.toLowerCase().equals("citi")) {

				// check prefix for City bank
				if(vaId.startsWith("9820") || vaId.startsWith("9821")) {
					selectSql = NkVaCustomerReadConstants.READ_CITY_CUSTOMER;
				} else {
					throw new Exception(
							"For Citibank, input parameter VA_ID should have 9820 or 9821 as prefix ");					
				}
			} else if (bankName.toLowerCase().equals("mandiri")) {

				// check prefix for Mandiri bank
				if(vaId.startsWith("8890030") || vaId.startsWith("8890130")) {
					selectSql = NkVaCustomerReadConstants.READ_MANDIRI_CUSTOMER;
				} else {
					throw new Exception(
							"For Mandiri Bank, input parameter VA_ID should have 8890030  or 8890130  as prefix ");				
				}
			} else {

				throw new Exception(
						"Not a valid Bank for Virtual account. Input parameter BANK should be CITI/MANDIRI");
			}			

			
			_log.info("SQL : " + selectSql);

			// output list
			SVLObjectList svlObjectList = xFactory.createSVLObjectList();
			
			DataReadQuery localDataReadQuery = new DataReadQuery();
			
			localDataReadQuery.setSQLString(selectSql);

			localDataReadQuery.addArgument("VA_ID");
			Vector select_arg = new Vector();
			select_arg.add(vaId);

			localDataReadQuery.addArgument("BANK");
			select_arg.add(bankName);
			
			Vector customerDetailsResult = (Vector) TransactionContext.getCurrent()
					.getUnitOfWork().executeQuery(localDataReadQuery, select_arg);		
			
			// No customer details found
			if (customerDetailsResult.isEmpty() || customerDetailsResult.size() == 0) {
				_log.info("No matching VA_ID found");

				throw new Exception(
						"No matching VA_ID found");

			} else {
				// set output values
				for (Object localObject : customerDetailsResult) {
					DatabaseRecord localDatabaseRecord = (DatabaseRecord) localObject;

					SVLObject listElement = xFactory.createSVLObject();

					listElement.setValue("CUSTOMER_ID",
							((BigDecimal) localDatabaseRecord
									.get("ICT.CUSTOMER_ID")).longValue());

					listElement.setValue("CUSTNUM",
							localDatabaseRecord.get("CUSTNUM"));
										
					svlObjectList.add(listElement);
				}
			}
			pOutput.setValue("RESULT_CUST_INFO_LIST", svlObjectList);
		}

		catch (ComponentException ex) {

			_log.finest("Exception from NkVaCustomerRead API:"
					+ ex.getMessage());
			ex.printStackTrace();

			throw new ComponentException(
					" There was an issue processing your request");
		}

		catch (Exception ex) {

			_log.finest("Exception from NkVaCustomerRead.java:" + ex.getMessage());
			ex.printStackTrace();

			throw new ComponentException(ex.getMessage());
		}

	}

	@Override
	public void initialize() {
		try {
			_log.log(Level.ALL, "Initializing " + COMMAND_NAME);
			ImplementationRegistry.registerImplementation(COMMAND_NAME,
					COMMAND_VERSION, this); // Register the command within the
											// SOI server
		} catch (InconsistentRegistryException ex) {
			_log.log(Level.SEVERE, "Internal Error", ex);
			ex.printStackTrace();
		}

	}

}
